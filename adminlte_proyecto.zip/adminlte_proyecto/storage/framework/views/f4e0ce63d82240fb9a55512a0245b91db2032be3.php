

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="display-1">Lista de Candidatos</h1>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <?php if(session('mensaje')): ?>
        <div class="row">
            <div class="col">
                <div class="alert alert-success  alert-dismissible fade show" role="alert">
                    <strong>¡Excelente!</strong> <?php echo e(session('mensaje')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if(session('candidato')): ?>
        <div class="row">
            <div class="col">
                <div class="alert alert-danger  alert-dismissible fade show" role="alert">
                    <strong>Lo sentimos </strong> <?php echo e(session('candidato')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if(session('candidato_inscrito')): ?>
        <div class="row">
            <div class="col">
                <div class="alert alert-success  alert-dismissible fade show" role="alert">
                    <strong>¡Genial! </strong> <?php echo e(session('candidato_inscrito')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
    <h5 class="mt-4 mb-2">Listado por grados y cargos de los candidatos</h5>

    <div class="row">
        <div class="col-12">
            <!-- Custom Tabs -->
            <div class="card">
                <div class="card-header d-flex p-0">
                    <h3 class="card-title p-3">Categorias</h3>
                    <ul class="nav nav-pills ml-auto p-2">
                        <li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">Todos</a></li>
                        <li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab">Tercero</a></li>
                        <li class="nav-item"><a class="nav-link" href="#tab_3" data-toggle="tab">Cuarto</a></li>
                        <li class="nav-item"><a class="nav-link" href="#tab_4" data-toggle="tab">Quinto</a></li>
                        <li class="nav-item"><a class="nav-link" href="#tab_5" data-toggle="tab">Sexto</a></li>
                        <li class="nav-item"><a class="nav-link" href="#tab_6" data-toggle="tab">Septimo</a></li>
                        <li class="nav-item"><a class="nav-link" href="#tab_7" data-toggle="tab">Octavo</a></li>
                        <li class="nav-item"><a class="nav-link" href="#tab_8" data-toggle="tab">Noveno</a></li>
                        <li class="nav-item"><a class="nav-link" href="#tab_9" data-toggle="tab">Decimo</a></li>
                        <li class="nav-item"><a class="nav-link" href="#tab_10" data-toggle="tab">Undecimo</a></li>
                    </ul>
                </div><!-- /.card-header -->
                <div class="card-body">
                    <div class="tab-content">
                        <div class="tab-pane active" id="tab_1">
                            <div class="row ">
                                <div class="col">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">Todos los candidatos</h3>
                                        </div>
                                        <!-- /.card-header todos-->
                                        <div class="card-body">
                                            <table id="todos" class="table table-bordered table-striped text-center">
                                                <thead>
                                                    <tr>
                                                        <th>identificacion</th>
                                                        <th>Nombre</th>
                                                        <th>Apellido(s)</th>
                                                        <th>Curso</th>
                                                        <th>Cargo</th>
                                                        <th>Editar</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $candidato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>

                                                            <td><?php echo e($item->estudiantes->identificacion); ?></td>
                                                            <td><?php echo e($item->estudiantes->nombre); ?></td>
                                                            <td><?php echo e($item->estudiantes->apellido); ?></td>
                                                            <td><?php echo e($item->estudiantes->cursos->numero_curso); ?></td>
                                                            <td><?php echo e($item->cargos->nombre_cargo); ?></td>
                                                            <td><a href="" class="btn btn-info btn-sm">Editar</a>
                                                            </td>

                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>

                                            </table>
                                        </div>
                                        <!-- /.card-body -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.tab-pane Tercero-->
                        <div class="tab-pane" id="tab_2">
                            <div class="row justify-content-center">
                                <div class="col">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">Tercero</h3>
                                        </div>
                                        <div class="card-body">

                                            <table class="table table-bordered table-striped text-center" id="tercero">
                                                <thead>
                                                    <tr>
                                                        <th>identificacion</th>
                                                        <th>Nombre</th>
                                                        <th>Apellido(s)</th>
                                                        <th>Curso</th>
                                                        <th>Cargo</th>
                                                        <th>Editar</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $candidato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($item->estudiantes->cursos->grados->numero_grado == 3): ?>
                                                            <tr>
                                                                <td><?php echo e($item->estudiantes->identificacion); ?></td>
                                                                <td><?php echo e($item->estudiantes->nombre); ?></td>
                                                                <td><?php echo e($item->estudiantes->apellido); ?></td>
                                                                <td><?php echo e($item->estudiantes->cursos->numero_curso); ?></td>
                                                                <td><?php echo e($item->cargos->nombre_cargo); ?></td>
                                                                <td><a href="" class="btn btn-info btn-sm">Editar</a>
                                                                </td>

                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>

                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>



                        </div>
                        <!-- /.tab-pane cuarto-->
                        <div class="tab-pane" id="tab_3">
                            <div class="row justify-content-center">
                                <div class="col">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">Cuarto</h3>
                                        </div>
                                        <div class="card-body">

                                            <table class="table table-bordered table-striped text-center" id="cuarto">
                                                <thead>
                                                    <tr>
                                                        <th>identificacion</th>
                                                        <th>Nombre</th>
                                                        <th>Apellido(s)</th>
                                                        <th>Curso</th>
                                                        <th>Cargo</th>
                                                        <th>Editar</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $candidato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($item->estudiantes->cursos->grados->numero_grado == 4): ?>
                                                            <tr>
                                                                <td><?php echo e($item->estudiantes->identificacion); ?></td>
                                                                <td><?php echo e($item->estudiantes->nombre); ?></td>
                                                                <td><?php echo e($item->estudiantes->apellido); ?></td>
                                                                <td><?php echo e($item->estudiantes->cursos->numero_curso); ?></td>
                                                                <td><?php echo e($item->cargos->nombre_cargo); ?></td>
                                                                <td><a href="" class="btn btn-info btn-sm">Editar</a>
                                                                </td>

                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>

                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>



                        </div>
                        <!-- /.tab-pane Quinto-->
                        <div class="tab-pane" id="tab_4">
                            <div class="row justify-content-center">
                                <div class="col">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">Quinto</h3>
                                        </div>
                                        <div class="card-body">

                                            <table class="table table-bordered table-striped text-center" id="quinto">
                                                <thead>
                                                    <tr>
                                                        <th>identificacion</th>
                                                        <th>Nombre</th>
                                                        <th>Apellido(s)</th>
                                                        <th>Curso</th>
                                                        <th>Cargo</th>
                                                        <th>Editar</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $candidato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($item->estudiantes->cursos->grados->numero_grado == 5): ?>
                                                            <tr>
                                                                <td><?php echo e($item->estudiantes->identificacion); ?></td>
                                                                <td><?php echo e($item->estudiantes->nombre); ?></td>
                                                                <td><?php echo e($item->estudiantes->apellido); ?></td>
                                                                <td><?php echo e($item->estudiantes->cursos->numero_curso); ?></td>
                                                                <td><?php echo e($item->cargos->nombre_cargo); ?></td>
                                                                <td><a href=""
                                                                        class="btn btn-info btn-sm">Editar</a>
                                                                </td>

                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>

                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                        <!-- /.tab-pane sexto-->
                        <div class="tab-pane" id="tab_5">
                            <div class="row justify-content-center">
                                <div class="col">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">Sexto</h3>
                                        </div>
                                        <div class="card-body">

                                            <table class="table table-bordered table-striped text-center" id="sexto">
                                                <thead>
                                                    <tr>
                                                        <th>identificacion</th>
                                                        <th>Nombre</th>
                                                        <th>Apellido(s)</th>
                                                        <th>Curso</th>
                                                        <th>Cargo</th>
                                                        <th>Editar</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $candidato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($item->estudiantes->cursos->grados->numero_grado == 6): ?>
                                                            <tr>
                                                                <td><?php echo e($item->estudiantes->identificacion); ?></td>
                                                                <td><?php echo e($item->estudiantes->nombre); ?></td>
                                                                <td><?php echo e($item->estudiantes->apellido); ?></td>
                                                                <td><?php echo e($item->estudiantes->cursos->numero_curso); ?></td>
                                                                <td><?php echo e($item->cargos->nombre_cargo); ?></td>
                                                                <td><a href=""
                                                                        class="btn btn-info btn-sm">Editar</a>
                                                                </td>

                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>

                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                        <!-- /.tab-pane septimo-->
                        <div class="tab-pane" id="tab_6">
                            <div class="row justify-content-center">
                                <div class="col">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">Septimo</h3>
                                        </div>
                                        <div class="card-body">

                                            <table class="table table-bordered table-striped text-center" id="septimo">
                                                <thead>
                                                    <tr>
                                                        <th>identificacion</th>
                                                        <th>Nombre</th>
                                                        <th>Apellido(s)</th>
                                                        <th>Curso</th>
                                                        <th>Cargo</th>
                                                        <th>Editar</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $candidato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($item->estudiantes->cursos->grados->numero_grado == 7): ?>
                                                            <tr>
                                                                <td><?php echo e($item->estudiantes->identificacion); ?></td>
                                                                <td><?php echo e($item->estudiantes->nombre); ?></td>
                                                                <td><?php echo e($item->estudiantes->apellido); ?></td>
                                                                <td><?php echo e($item->estudiantes->cursos->numero_curso); ?></td>
                                                                <td><?php echo e($item->cargos->nombre_cargo); ?></td>
                                                                <td><a href=""
                                                                        class="btn btn-info btn-sm">Editar</a>
                                                                </td>

                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>

                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                        <!-- /.tab-pane Octavo -->
                        <div class="tab-pane" id="tab_7">
                            <div class="row justify-content-center">
                                <div class="col">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">Octavo</h3>
                                        </div>
                                        <div class="card-body">

                                            <table class="table table-bordered table-striped text-center" id="octavo">
                                                <thead>
                                                    <tr>
                                                        <th>identificacion</th>
                                                        <th>Nombre</th>
                                                        <th>Apellido(s)</th>
                                                        <th>Curso</th>
                                                        <th>Cargo</th>
                                                        <th>Editar</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $candidato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($item->estudiantes->cursos->grados->numero_grado == 8): ?>
                                                            <tr>
                                                                <td><?php echo e($item->estudiantes->identificacion); ?></td>
                                                                <td><?php echo e($item->estudiantes->nombre); ?></td>
                                                                <td><?php echo e($item->estudiantes->apellido); ?></td>
                                                                <td><?php echo e($item->estudiantes->cursos->numero_curso); ?></td>
                                                                <td><?php echo e($item->cargos->nombre_cargo); ?></td>
                                                                <td><a href=""
                                                                        class="btn btn-info btn-sm">Editar</a>
                                                                </td>

                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>

                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                        <!-- /.tab-pane Noveno-->
                        <div class="tab-pane" id="tab_8">
                            <div class="row justify-content-center">
                                <div class="col">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">Noveno</h3>
                                        </div>
                                        <div class="card-body">

                                            <table class="table table-bordered table-striped text-center" id="noveno">
                                                <thead>
                                                    <tr>
                                                        <th>identificacion</th>
                                                        <th>Nombre</th>
                                                        <th>Apellido(s)</th>
                                                        <th>Curso</th>
                                                        <th>Cargo</th>
                                                        <th>Editar</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $candidato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($item->estudiantes->cursos->grados->numero_grado == 9): ?>
                                                            <tr>
                                                                <td><?php echo e($item->estudiantes->identificacion); ?></td>
                                                                <td><?php echo e($item->estudiantes->nombre); ?></td>
                                                                <td><?php echo e($item->estudiantes->apellido); ?></td>
                                                                <td><?php echo e($item->estudiantes->cursos->numero_curso); ?></td>
                                                                <td><?php echo e($item->cargos->nombre_cargo); ?></td>
                                                                <td><a href=""
                                                                        class="btn btn-info btn-sm">Editar</a>
                                                                </td>

                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>

                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                        <!-- /.tab-pane Decimo-->
                        <div class="tab-pane" id="tab_9">
                            <div class="row justify-content-center">
                                <div class="col">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">Decimo</h3>
                                        </div>
                                        <div class="card-body">

                                            <table class="table table-bordered table-striped text-center" id="decimo">
                                                <thead>
                                                    <tr>
                                                        <th>identificacion</th>
                                                        <th>Nombre</th>
                                                        <th>Apellido(s)</th>
                                                        <th>Curso</th>
                                                        <th>Cargo</th>
                                                        <th>Editar</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $candidato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($item->estudiantes->cursos->grados->numero_grado == 10): ?>
                                                            <tr>
                                                                <td><?php echo e($item->estudiantes->identificacion); ?></td>
                                                                <td><?php echo e($item->estudiantes->nombre); ?></td>
                                                                <td><?php echo e($item->estudiantes->apellido); ?></td>
                                                                <td><?php echo e($item->estudiantes->cursos->numero_curso); ?></td>
                                                                <td><?php echo e($item->cargos->nombre_cargo); ?></td>
                                                                <td><a href=""
                                                                        class="btn btn-info btn-sm">Editar</a>
                                                                </td>

                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>

                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                        <!-- /.tab-pane undecimo-->
                        <div class="tab-pane" id="tab_10">
                            <div class="row justify-content-center">
                                <div class="col">
                                    <div class="card">
                                        <div class="card-header">
                                            <h3 class="card-title">Undecimo</h3>
                                        </div>
                                        <div class="card-body">

                                            <table class="table table-bordered table-striped text-center" id="undecimo">
                                                <thead>
                                                    <tr>
                                                        <th>identificacion</th>
                                                        <th>Nombre</th>
                                                        <th>Apellido(s)</th>
                                                        <th>Curso</th>
                                                        <th>Cargo</th>
                                                        <th>Editar</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $candidato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($item->estudiantes->cursos->grados->numero_grado == 11): ?>
                                                            <tr>
                                                                <td><?php echo e($item->estudiantes->identificacion); ?></td>
                                                                <td><?php echo e($item->estudiantes->nombre); ?></td>
                                                                <td><?php echo e($item->estudiantes->apellido); ?></td>
                                                                <td><?php echo e($item->estudiantes->cursos->numero_curso); ?></td>
                                                                <td><?php echo e($item->cargos->nombre_cargo); ?></td>
                                                                <td><a href=""
                                                                        class="btn btn-info btn-sm">Editar</a>
                                                                </td>

                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>

                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                        <!-- /.tab-pane -->
                    </div>
                    <!-- /.tab-content -->
                </div><!-- /.card-body -->
            </div>
            <!-- ./card -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
    <!-- END CUSTOM TABS -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('#todos').DataTable();
        $('#tercero').DataTable();
        $('#cuarto').DataTable();
        $('#quinto').DataTable();
        $('#sexto').DataTable();
        $('#septimo').DataTable();
        $('#octavo').DataTable();
        $('#noveno').DataTable();
        $('#decimo').DataTable();
        $('#undecimo').DataTable();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Click_Voto\adminlte_proyecto\resources\views/listaCandidatos.blade.php ENDPATH**/ ?>